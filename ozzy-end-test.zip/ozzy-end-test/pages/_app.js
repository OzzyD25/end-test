import React, { Fragment } from "react";
import App from "next/app";

import "../styles/globals.css";

// components
import Header from "../components/Header";
// import Footer from "../components/Footer";

export default class MyApp extends App {
  static async getInitialProps({ Component, router, ctx }) {
    let pageProps = {};
    if (Component.getInitialProps) {
      pageProps = await Component.getInitialProps(ctx);
    }

    if (router) return { pageProps };
  }

  render() {
    const { Component, pageProps } = this.props;

    return (
      <Fragment>
        <Header />
        <Component {...pageProps} />
        {/* <Footer /> */}
      </Fragment>
    );
  }
}

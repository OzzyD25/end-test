import React from "react";
import StyledFooter from "./StyledFooter";

const Footer = () => {
  return <StyledFooter>hello from Footer</StyledFooter>;
};

export default Footer;

import React from "react";
import StyledLink from "./styles/StyledLink";

const HeaderLink = ({ link, activateDropdown, activeLink, setData }) => {
  const setCurrentData = (e) => {
    if (activeLink !== link.name) {
      activateDropdown(e);
    }
    setData(link);
  };

  return (
    <StyledLink
      onMouseEnter={setCurrentData}
      id={link.name}
      active={activeLink === link.name && true}
    >
      {link.name}
    </StyledLink>
  );
};

export default HeaderLink;

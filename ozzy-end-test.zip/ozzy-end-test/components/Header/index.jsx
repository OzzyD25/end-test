import React from "react";
import Link from "next/link";
import HeaderNav from "./HeaderNav";
import StyledHeader from "./styles/StyledHeader";

import navCatagories from "../../utility/testData";

const Header = ({ data }) => {
  if (data || navCatagories) {
    return (
      <StyledHeader>
        <div className="header-banner">
          <span>
            Free UK delivery on all orders over £150 | free uk returns
          </span>
        </div>
        <div className="header-content">
          <div className="header-content__regionLogin">
            <div>
              <span>Flag</span>
              <span>United Kingdom</span>
            </div>
            <div>
              <span>Help</span>
              <span>Log in</span>
            </div>
          </div>
          <div className="header-content__logoAndOptions">
            <Link href="/">
              <a>END.</a>
            </Link>
            <div>
              <span>S</span>
              <span>B</span>
            </div>
          </div>
        </div>
        <HeaderNav navCatagories={navCatagories} />
      </StyledHeader>
    );
  }
};

export async function getServerSideProps() {
  // Fetch Header Data
  const res = await fetch(`https://dummyURlHeader`);
  const data = await res.json();

  return { props: { data } };
}

export default Header;

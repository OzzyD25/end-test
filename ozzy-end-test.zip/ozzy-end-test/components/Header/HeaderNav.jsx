import React, { useState } from "react";
import StyledNav from "./styles/StyledNav";
import HeaderLink from "./HeaderLink";
import HeaderDropdown from "./HeaderDropdown";

const HeaderNav = ({ navCatagories }) => {
  const [dropdownActive, setDropdownActive] = useState(false);
  const [activeLink, setActiveLink] = useState(false);
  const [data, setData] = useState([]);

  // set id for styling, dropdown config
  const activateDropdown = (event) => {
    const id = event.currentTarget.id;

    setDropdownActive(true);
    setActiveLink(id);
  };

  // revert dropdown display and config
  const cancelDropdown = () => {
    setDropdownActive(false);
    setActiveLink(false);
  };

  return (
    <StyledNav dropdownActive={dropdownActive} onMouseLeave={cancelDropdown}>
      <ul>
        {navCatagories.map((link, i) => (
          <HeaderLink
            link={link}
            key={`header-link-${i}`}
            activeLink={activeLink}
            activateDropdown={activateDropdown}
            setData={setData}
          />
        ))}
      </ul>
      {dropdownActive && <HeaderDropdown data={data} activeLink={activeLink} />}
    </StyledNav>
  );
};

export default HeaderNav;

{
  /* <HeaderDropdown childrenData={childrenData} activeLink={activeLink} /> */
}

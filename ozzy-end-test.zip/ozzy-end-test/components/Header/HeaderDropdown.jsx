import React, { useEffect, useState } from "react";
import StyledDropdown from "./styles/StyledDropdown";

const HeaderDropdown = ({ data, activeLink }) => {
  const [hasImages, setHasImages] = useState(false);
  const [columns, setColumns] = useState([]);

  const splitColumns = () => {
    let firstArr = [];
    let secondArr = [];
    let thirdArr = [];

    // check for images
    if (data.dropdown_image_enabled) {
      setHasImages(true);
    } else {
      setHasImages(false);
    }

    // sort columns into seperate array
    data.children_data.map((child) => {
      switch (true) {
        case child.include_in_menu_column2:
          secondArr.push(child);
          break;
        case child.include_in_menu_column3:
          thirdArr.push(child);
          break;
        case !child.include_in_menu_column2 && !child.include_in_menu_column3:
          firstArr.push(child);
          break;
      }
    });
    setColumns([firstArr, secondArr, thirdArr]);
  };

  useEffect(() => {
    splitColumns();
  }, [data]);

  return (
    <StyledDropdown hasImages={hasImages}>
      <div className="dropdown">
        <div
          className="dropdown__list"
          style={{ width: !columns[1] ? "50%" : "25%" }}
        >
          <p>{`View all ${activeLink}`}</p>
          {columns[0] &&
            columns[0].map((item, i) => (
              <p key={`item-${i} column-1`}>{item.name}</p>
            ))}
        </div>
        <div
          className="dropdown__list"
          style={{ width: !columns[0] ? "50%" : "25%" }}
        >
          {columns[1] &&
            columns[1].map((item, i) => (
              <p key={`item-${i} column-2`}>{item.name}</p>
            ))}
        </div>
        {hasImages && (
          <div className="dropdown__images">
            {data.dropdown_image_link && (
              <div>
                <img src={data.dropdown_image_url} />
                <p>{data.dropdown_image_title}</p>
              </div>
            )}
            {data.dropdown_image_link1 && (
              <div>
                <img src={data.dropdown_image_url1} />
                <p>{data.dropdown_image_title1}</p>
              </div>
            )}
            {data.dropdown_image_link2 && (
              <div>
                <img src={data.dropdown_image_url2} />
                <p>{data.dropdown_image_title2}</p>
              </div>
            )}
            {data.dropdown_image_link3 && (
              <div>
                <img src={data.dropdown_image_url3} />
                <p>{data.dropdown_image_title3}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </StyledDropdown>
  );
};

export default HeaderDropdown;

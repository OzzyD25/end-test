import React from "react";
import StyledLayoutContainer from "./StyledLayoutContainer";

const Layout = ({ children }) => {
  return <StyledLayoutContainer>{children}</StyledLayoutContainer>;
};

export default Layout;

import styled from "styled-components";

export default styled.div`
  width: 100%;
  overflow-x: hidden;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
`;
